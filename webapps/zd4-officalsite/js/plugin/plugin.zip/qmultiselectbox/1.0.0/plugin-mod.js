define(["jquery/qmultiplyfilter/1.0.0/jquery.qmultiplyfilter.css"], 
function(require, exports) {
	
	
	
	
	
	
	return jQuery;
}
);