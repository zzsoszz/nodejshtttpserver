# qmultiplyfilter
jquery plugin
