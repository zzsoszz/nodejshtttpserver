# 
jquery plugin

http://192.168.1.213:3000/html5/js/plugin/qmultiselectboxwithinput/1.0.1/demo.html