window.onload=function(){
    var file=document.querySelector("input[type='file']");
    var file_div=document.querySelector("#file_div");
    var container=document.querySelector("#content");
    var pic_info=document.querySelector("#originPicSize");
    var crop=document.querySelector("#crop");
    var a=document.querySelector("a");
    var crop_pic=document.querySelector("#crop_pic");
    var confirm=document.querySelector("#confirm");
    var cancel=document.querySelector("#cancel");
    var reopen=document.querySelector("#reopen");
    var img;
    var origin_height=200;
    var flag=true;
    var change_containerHeight=function(addHeight){
        console.log(addHeight);
        //console.log(container.style.height);    //height不包含 border
        //console.log(container.offsetHeight);    //offsetHeight 包含了border
        container.style.height =container.offsetHeight+addHeight-4+"px";
        file_div.style.height =file_div.offsetHeight+addHeight-2+"px";
    }
    //点击裁剪
    var moveMask_function=function(){
        var moveMask=document.querySelector("#moveMask");
        var canvas=document.querySelector("canvas");
        var  detectMoveMaskRange=function(){
            if(moveMask.offsetTop>canvas.offsetTop+canvas.height-moveMask.offsetHeight){
                 moveMask.style.top= canvas.offsetTop+canvas.height-moveMask.offsetHeight+"px";
            }
            if(moveMask.offsetLeft<canvas.offsetLeft){
                moveMask.style.left=canvas.offsetLeft +"px";
            }
            if(moveMask.offsetTop<canvas.offsetTop){
                moveMask.style.top=canvas.offsetTop+"px";
            }
            if(moveMask.offsetLeft>canvas.offsetLeft+canvas.offsetWidth-moveMask.offsetWidth){
                moveMask.style.left=canvas.offsetLeft+canvas.offsetWidth-moveMask.offsetWidth+"px";
            }
        }
        moveMask.onmousedown=function(e){
            var startX= e.clientX,
                startY= e.clientY,
                top=moveMask.offsetTop,
                left = moveMask.offsetLeft;

                document.onmousemove=function(e){
                var x= e.clientX;
                var y= e.clientY;

                //set the location of the clip region.
                moveMask.style.top=top+y-startY+"px";
                moveMask.style.left=left+x-startX+"px";
                detectMoveMaskRange();
                this.onmouseup = document.onmouseup = function() {
                    document.onmousemove = null;
                };
            }
            return false;
        }
    }
    var  corner_function=function(){
        var moveMask=document.querySelector("#moveMask");
        var canvas=document.querySelector("canvas");
        var drag_left=document.querySelector(".drag_left");
        var drag_right=document.querySelector(".drag_right");
        drag_left.onmousedown=function(e){
            var startX= e.clientX,
                startY= e.clientY,
                left=moveMask.offsetLeft,
                top=moveMask.offsetTop,
                height=moveMask.offsetHeight,
                width = moveMask.offsetWidth;
                document.onmousemove=function(e) {
                        console.log("width:"+moveMask.offsetWidth);
                        console.log("height:"+moveMask.offsetHeight);
                        var x = e.clientX;
                        var y = e.clientY;
                       if (moveMask.offsetWidth > 20 && moveMask.offsetHeight > 20||x-startX<0) {
                           moveMask.style.left = left + x - startX + "px";
                           moveMask.style.top = top + y - startY + "px";
                           moveMask.style.width = width - (x - startX) + "px";
                           moveMask.style.height = height - (y - startY) + "px";
                           if (moveMask.offsetLeft < canvas.offsetLeft) {
                               moveMask.style.left = canvas.offsetLeft + "px";
                           }
                           if (moveMask.offsetTop < canvas.offsetTop) {
                               moveMask.style.top = canvas.offsetTop + "px";
                           }
                       }

                }
            this.onmouseup = document.onmouseup = function() {
                document.onmousemove = null;
            }
            //阻止冒泡
            e.stopPropagation();
            return false;
        }
        drag_right.onmousedown=function(e){
            var startX= e.clientX,
                startY= e.clientY,
                height=moveMask.offsetHeight,
                width = moveMask.offsetWidth;

                document.onmousemove=function(e) {
                 var x = e.clientX,
                  y = e.clientY;
                     if (moveMask.offsetWidth > 20 && moveMask.offsetHeight > 20||x-startX>0) {
                         moveMask.style.height = height + y - startY + "px";
                         moveMask.style.width = width + x - startX + "px";
                     }
                     if (moveMask.offsetTop + moveMask.offsetHeight > canvas.offsetTop + canvas.offsetHeight) {
                         moveMask.style.height = canvas.offsetHeight + "px";
                     }
                     if (moveMask.offsetLeft + moveMask.offsetWidth >= canvas.offsetLeft + canvas.offsetWidth) {
                         moveMask.style.width = canvas.offsetWidth + "px";
                     }
                 }

            this.onmouseup = document.onmouseup = function() {
                document.onmousemove = null;
            }
            //阻止冒泡
            e.stopPropagation();
            return false;
        }

    }

    crop.addEventListener("click",function(){
        var canvas=document.querySelector("canvas");
        //图片加载后
        if(canvas){
            var crop=document.querySelector("#crop_pic");
            var moveMask=document.querySelector("#moveMask");
            crop.style.visibility="visible";
            if(flag){
                var moveMask=document.createElement("div");
                var drag_left=document.createElement("div");
                var drag_right=document.createElement("div");
                drag_left.className="drag_left";
                drag_right.className="drag_right";
                moveMask.appendChild(drag_right);
                moveMask.appendChild(drag_left);
                moveMask.id="moveMask";
                moveMask.style.position="absolute";
                moveMask.style.width=canvas.width/2+"px";
                moveMask.style.height=canvas.height/2+"px";
                moveMask.style.left=container.offsetWidth/2-canvas.width/2+"px";
                moveMask.style.opacity="0.3";
                moveMask.style.backgroundColor="#ff6666";
                moveMask.style.cursor="pointer";
                moveMask.style.zIndex="1";
                file_div.appendChild(moveMask);
                corner_function();
                moveMask_function();
                console.log(container.offsetWidth);
                console.log(canvas.offsetLeft);
                flag=false;
                crop_pic.addEventListener("click",function(){
                     var canvas=document.querySelector("canvas");
                     var moveMask=document.querySelector("#moveMask");
                     var sx=moveMask.offsetLeft-canvas.offsetLeft;
                     var sy=moveMask.offsetTop-canvas.offsetTop;
                     var originWidth=canvas.width;
                     var originHeight=canvas.height;
                     canvas.getContext('2d').clearRect(0,0,canvas.width,canvas.height);
                     canvas.width=moveMask.offsetWidth;
                     canvas.height=moveMask.offsetHeight;
                     canvas.getContext('2d').drawImage(img, sx, sy, moveMask.offsetWidth, moveMask.offsetHeight, 0, 0, moveMask.offsetWidth, moveMask.offsetHeight);
                     var download_link=document.querySelector("#download");
                     download_link.href=canvas.toDataURL();
                     download_link.download=file.name;
                     canvas.getContext('2d').clearRect(0,0,canvas.width,canvas.height);
                     canvas.width=originWidth;
                     canvas.height=originHeight;
                     canvas.getContext('2d').drawImage(img,0,0,img.width,img.height);
                     document.querySelector("#shadow").style.display="block";
                },false);
                cancel.addEventListener("click",function(){
                    document.querySelector("#shadow").style.display="none";
                },false);
                reopen.addEventListener("click",function(){
                     window.location.reload(true); //缓存里取当前页
                },false);
            }
        }
    },false);
    confirm.addEventListener('click',function(){
        var text=document.querySelectorAll("#img_size input[type='text']");
        //img 的宽高
        var width=text[0].value;
        var height=text[1].value;
        pic_info.innerHTML="宽 "+width+" | "+"高 "+height;
        var canvas=document.querySelector("canvas");
        if(canvas) {
            canvas.getContext('2d').clearRect(0,0,canvas.width,canvas.height);
            canvas.width = width;
            canvas.height = height;
            img.width=width;
            img.height=height;
            var addHeight=canvas.height-origin_height;
            change_containerHeight(addHeight);
            canvas.getContext('2d').drawImage(img,0,0,width,height);
            img.src=canvas.toDataURL();
            origin_height=height;
            var moveMask=document.querySelector("#moveMask");
            if(moveMask){
                moveMask.style.width=canvas.width/2+"px";
                moveMask.style.height=canvas.height/2+"px";
                moveMask.style.left=container.offsetWidth/2-canvas.width/2+"px";
            }
        }
    },false);
    file.addEventListener("change",function(){
        file=this.files[0];
        console.log(file.type);
        console.log(file);
        if(!/image/g.test(file.type)) {
            return alert('只能上传图片！');
        }
        if(!/jpg|jpeg|png/g.test(file.type)) {
            return alert('不支持的图片类型！');
        }
        if(file.size > 1024 * 1024 * 10) {
            return alert('图片超过限制大小了，最大上传10mb的图片！');
        }
        var reader=new FileReader();
        img=new Image();
        reader.readAsDataURL(file);
        reader.onload=function(e){
            var show_img_canvas=document.createElement('canvas');
            show_img_canvas.style.backgroundColor="#A00";
            //设置 canvas 的初始状态
            show_img_canvas.width="200";
            show_img_canvas.height="200";
            img.src= e.target.result;
            img.width=200;
            img.height=200;
            //图片元素 图片剪切的x坐标位置 剪切的y坐标位置 被剪切图像的宽度 被剪切图像的高度 在画布上放置图像的x坐标位置
            //在画布上放置图像的y坐标位置  要使用的图像的宽度 要使用的图像的高度
            show_img_canvas.getContext("2d").drawImage(img,0,0,200,200);
            console.log("图片宽:"+img.width);
            console.log("图片高:"+img.height);
            console.log("canvas宽:"+show_img_canvas.width);
            console.log("canvas高:"+show_img_canvas.height);
            file_div.className +=" file_div_margin_change";
            //节点0 是标签间的空格
            file_div.replaceChild(show_img_canvas,file_div.childNodes[1]);
            pic_info.innerHTML="宽 200 | 高 200";
            //change_containerHeight(80);
        }
    },false)
}